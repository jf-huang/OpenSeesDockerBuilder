/* reg.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistdestroy_ PPETSCFLISTDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistdestroy_ ppetscflistdestroy
#else
#define petscflistdestroy_ ppetscflistdestroy_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistdestroy_ PETSCFLISTDESTROY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistdestroy_ petscflistdestroy
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistview_ PPETSCFLISTVIEW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistview_ ppetscflistview
#else
#define petscflistview_ ppetscflistview_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistview_ PETSCFLISTVIEW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistview_ petscflistview
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistget_ PPETSCFLISTGET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistget_ ppetscflistget
#else
#define petscflistget_ ppetscflistget_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistget_ PETSCFLISTGET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistget_ petscflistget
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistduplicate_ PPETSCFLISTDUPLICATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistduplicate_ ppetscflistduplicate
#else
#define petscflistduplicate_ ppetscflistduplicate_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscflistduplicate_ PETSCFLISTDUPLICATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscflistduplicate_ petscflistduplicate
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscflistdestroy_(PetscFList *fl, int *ierr ){
*ierr = PetscFListDestroy(
	(PetscFList* )PetscToPointer( (fl) ));
}
void PETSC_STDCALL  petscflistview_(PetscFList *list,PetscViewer *viewer, int *ierr ){
*ierr = PetscFListView(*list,*viewer);
}
void PETSC_STDCALL  petscflistget_(PetscFList *list,char ***array,int *n, int *ierr ){
*ierr = PetscFListGet(*list,array,n);
}
void PETSC_STDCALL  petscflistduplicate_(PetscFList *fl,PetscFList *nl, int *ierr ){
*ierr = PetscFListDuplicate(*fl,
	(PetscFList* )PetscToPointer( (nl) ));
}
#if defined(__cplusplus)
}
#endif
