/* icc.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscpc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetmatordering_ PPCICCSETMATORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetmatordering_ ppciccsetmatordering
#else
#define pciccsetmatordering_ ppciccsetmatordering_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetmatordering_ PCICCSETMATORDERING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetmatordering_ pciccsetmatordering
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetlevels_ PPCICCSETLEVELS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetlevels_ ppciccsetlevels
#else
#define pciccsetlevels_ ppciccsetlevels_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetlevels_ PCICCSETLEVELS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetlevels_ pciccsetlevels
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetfill_ PPCICCSETFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetfill_ ppciccsetfill
#else
#define pciccsetfill_ ppciccsetfill_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetfill_ PCICCSETFILL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetfill_ pciccsetfill
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetdamping_ PPCICCSETDAMPING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetdamping_ ppciccsetdamping
#else
#define pciccsetdamping_ ppciccsetdamping_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetdamping_ PCICCSETDAMPING
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetdamping_ pciccsetdamping
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetshift_ PPCICCSETSHIFT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetshift_ ppciccsetshift
#else
#define pciccsetshift_ ppciccsetshift_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetshift_ PCICCSETSHIFT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetshift_ pciccsetshift
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetzeropivot_ PPCICCSETZEROPIVOT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetzeropivot_ ppciccsetzeropivot
#else
#define pciccsetzeropivot_ ppciccsetzeropivot_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define pciccsetzeropivot_ PCICCSETZEROPIVOT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define pciccsetzeropivot_ pciccsetzeropivot
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  pciccsetmatordering_(PC pc,MatOrderingType *ordering, int *ierr ){
*ierr = PCICCSetMatOrdering(
	(PC)PetscToPointer( (pc) ),*ordering);
}
void PETSC_STDCALL  pciccsetlevels_(PC pc,PetscInt *levels, int *ierr ){
*ierr = PCICCSetLevels(
	(PC)PetscToPointer( (pc) ),*levels);
}
void PETSC_STDCALL  pciccsetfill_(PC pc,PetscReal *fill, int *ierr ){
*ierr = PCICCSetFill(
	(PC)PetscToPointer( (pc) ),*fill);
}
void PETSC_STDCALL  pciccsetdamping_(PC pc,PetscReal *damping, int *ierr ){
*ierr = PCICCSetDamping(
	(PC)PetscToPointer( (pc) ),*damping);
}
void PETSC_STDCALL  pciccsetshift_(PC pc,PetscTruth *shift, int *ierr ){
*ierr = PCICCSetShift(
	(PC)PetscToPointer( (pc) ),*shift);
}
void PETSC_STDCALL  pciccsetzeropivot_(PC pc,PetscReal *zero, int *ierr ){
*ierr = PCICCSetZeroPivot(
	(PC)PetscToPointer( (pc) ),*zero);
}
#if defined(__cplusplus)
}
#endif
