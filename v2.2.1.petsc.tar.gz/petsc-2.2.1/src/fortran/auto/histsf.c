/* hists.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgsetnumberbins_ PPETSCDRAWHGSETNUMBERBINS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgsetnumberbins_ ppetscdrawhgsetnumberbins
#else
#define petscdrawhgsetnumberbins_ ppetscdrawhgsetnumberbins_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgsetnumberbins_ PETSCDRAWHGSETNUMBERBINS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgsetnumberbins_ petscdrawhgsetnumberbins
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgreset_ PPETSCDRAWHGRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgreset_ ppetscdrawhgreset
#else
#define petscdrawhgreset_ ppetscdrawhgreset_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgreset_ PETSCDRAWHGRESET
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgreset_ petscdrawhgreset
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgaddvalue_ PPETSCDRAWHGADDVALUE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgaddvalue_ ppetscdrawhgaddvalue
#else
#define petscdrawhgaddvalue_ ppetscdrawhgaddvalue_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgaddvalue_ PETSCDRAWHGADDVALUE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgaddvalue_ petscdrawhgaddvalue
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgdraw_ PPETSCDRAWHGDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgdraw_ ppetscdrawhgdraw
#else
#define petscdrawhgdraw_ ppetscdrawhgdraw_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgdraw_ PETSCDRAWHGDRAW
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgdraw_ petscdrawhgdraw
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgprint_ PPETSCDRAWHGPRINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgprint_ ppetscdrawhgprint
#else
#define petscdrawhgprint_ ppetscdrawhgprint_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgprint_ PETSCDRAWHGPRINT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgprint_ petscdrawhgprint
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgsetcolor_ PPETSCDRAWHGSETCOLOR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgsetcolor_ ppetscdrawhgsetcolor
#else
#define petscdrawhgsetcolor_ ppetscdrawhgsetcolor_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgsetcolor_ PETSCDRAWHGSETCOLOR
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgsetcolor_ petscdrawhgsetcolor
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgsetlimits_ PPETSCDRAWHGSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgsetlimits_ ppetscdrawhgsetlimits
#else
#define petscdrawhgsetlimits_ ppetscdrawhgsetlimits_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgsetlimits_ PETSCDRAWHGSETLIMITS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgsetlimits_ petscdrawhgsetlimits
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgcalcstats_ PPETSCDRAWHGCALCSTATS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgcalcstats_ ppetscdrawhgcalcstats
#else
#define petscdrawhgcalcstats_ ppetscdrawhgcalcstats_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgcalcstats_ PETSCDRAWHGCALCSTATS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgcalcstats_ petscdrawhgcalcstats
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgintegerbins_ PPETSCDRAWHGINTEGERBINS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgintegerbins_ ppetscdrawhgintegerbins
#else
#define petscdrawhgintegerbins_ ppetscdrawhgintegerbins_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdrawhgintegerbins_ PETSCDRAWHGINTEGERBINS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdrawhgintegerbins_ petscdrawhgintegerbins
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscdrawhgsetnumberbins_(PetscDrawHG *hist,int *bins, int *ierr ){
*ierr = PetscDrawHGSetNumberBins(*hist,*bins);
}
void PETSC_STDCALL  petscdrawhgreset_(PetscDrawHG *hist, int *ierr ){
*ierr = PetscDrawHGReset(*hist);
}
void PETSC_STDCALL  petscdrawhgaddvalue_(PetscDrawHG *hist,PetscReal *value, int *ierr ){
*ierr = PetscDrawHGAddValue(*hist,*value);
}
void PETSC_STDCALL  petscdrawhgdraw_(PetscDrawHG *hist, int *ierr ){
*ierr = PetscDrawHGDraw(*hist);
}
void PETSC_STDCALL  petscdrawhgprint_(PetscDrawHG *hist, int *ierr ){
*ierr = PetscDrawHGPrint(*hist);
}
void PETSC_STDCALL  petscdrawhgsetcolor_(PetscDrawHG *hist,int *color, int *ierr ){
*ierr = PetscDrawHGSetColor(*hist,*color);
}
void PETSC_STDCALL  petscdrawhgsetlimits_(PetscDrawHG *hist,PetscReal *x_min,PetscReal *x_max,int *y_min,int *y_max, int *ierr ){
*ierr = PetscDrawHGSetLimits(*hist,*x_min,*x_max,*y_min,*y_max);
}
void PETSC_STDCALL  petscdrawhgcalcstats_(PetscDrawHG *hist,PetscTruth *calc, int *ierr ){
*ierr = PetscDrawHGCalcStats(*hist,*calc);
}
void PETSC_STDCALL  petscdrawhgintegerbins_(PetscDrawHG *hist,PetscTruth *ints, int *ierr ){
*ierr = PetscDrawHGIntegerBins(*hist,*ints);
}
#if defined(__cplusplus)
}
#endif
