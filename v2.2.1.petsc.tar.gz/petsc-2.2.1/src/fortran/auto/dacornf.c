/* dacorn.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscda.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dasetcoordinates_ PDASETCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dasetcoordinates_ pdasetcoordinates
#else
#define dasetcoordinates_ pdasetcoordinates_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dasetcoordinates_ DASETCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dasetcoordinates_ dasetcoordinates
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetcoordinates_ PDAGETCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetcoordinates_ pdagetcoordinates
#else
#define dagetcoordinates_ pdagetcoordinates_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetcoordinates_ DAGETCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetcoordinates_ dagetcoordinates
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetcoordinateda_ PDAGETCOORDINATEDA
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetcoordinateda_ pdagetcoordinateda
#else
#define dagetcoordinateda_ pdagetcoordinateda_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetcoordinateda_ DAGETCOORDINATEDA
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetcoordinateda_ dagetcoordinateda
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetghostedcoordinates_ PDAGETGHOSTEDCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetghostedcoordinates_ pdagetghostedcoordinates
#else
#define dagetghostedcoordinates_ pdagetghostedcoordinates_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetghostedcoordinates_ DAGETGHOSTEDCOORDINATES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetghostedcoordinates_ dagetghostedcoordinates
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetcorners_ PDAGETCORNERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetcorners_ pdagetcorners
#else
#define dagetcorners_ pdagetcorners_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define dagetcorners_ DAGETCORNERS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define dagetcorners_ dagetcorners
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  dasetcoordinates_(DA da,Vec c, int *ierr ){
*ierr = DASetCoordinates(
	(DA)PetscToPointer( (da) ),
	(Vec)PetscToPointer( (c) ));
}
void PETSC_STDCALL  dagetcoordinates_(DA da,Vec *c, int *ierr ){
*ierr = DAGetCoordinates(
	(DA)PetscToPointer( (da) ),c);
}
void PETSC_STDCALL  dagetcoordinateda_(DA da,DA *cda, int *ierr ){
*ierr = DAGetCoordinateDA(
	(DA)PetscToPointer( (da) ),cda);
}
void PETSC_STDCALL  dagetghostedcoordinates_(DA da,Vec *c, int *ierr ){
*ierr = DAGetGhostedCoordinates(
	(DA)PetscToPointer( (da) ),c);
}
void PETSC_STDCALL  dagetcorners_(DA da,PetscInt *x,PetscInt *y,PetscInt *z,PetscInt *m,PetscInt *n,PetscInt *p, int *ierr ){
*ierr = DAGetCorners(
	(DA)PetscToPointer( (da) ),x,y,z,m,n,p);
}
#if defined(__cplusplus)
}
#endif
