/* plog.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogtracebegin_ PPETSCLOGTRACEBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogtracebegin_ ppetsclogtracebegin
#else
#define petsclogtracebegin_ ppetsclogtracebegin_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogtracebegin_ PETSCLOGTRACEBEGIN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogtracebegin_ petsclogtracebegin
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogactions_ PPETSCLOGACTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogactions_ ppetsclogactions
#else
#define petsclogactions_ ppetsclogactions_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogactions_ PETSCLOGACTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogactions_ petsclogactions
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogobjects_ PPETSCLOGOBJECTS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogobjects_ ppetsclogobjects
#else
#define petsclogobjects_ ppetsclogobjects_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogobjects_ PETSCLOGOBJECTS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogobjects_ petsclogobjects
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagesetactive_ PPETSCLOGSTAGESETACTIVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagesetactive_ ppetsclogstagesetactive
#else
#define petsclogstagesetactive_ ppetsclogstagesetactive_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagesetactive_ PETSCLOGSTAGESETACTIVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagesetactive_ petsclogstagesetactive
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagegetactive_ PPETSCLOGSTAGEGETACTIVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagegetactive_ ppetsclogstagegetactive
#else
#define petsclogstagegetactive_ ppetsclogstagegetactive_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagegetactive_ PETSCLOGSTAGEGETACTIVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagegetactive_ petsclogstagegetactive
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagesetvisible_ PPETSCLOGSTAGESETVISIBLE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagesetvisible_ ppetsclogstagesetvisible
#else
#define petsclogstagesetvisible_ ppetsclogstagesetvisible_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagesetvisible_ PETSCLOGSTAGESETVISIBLE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagesetvisible_ petsclogstagesetvisible
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagegetvisible_ PPETSCLOGSTAGEGETVISIBLE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagegetvisible_ ppetsclogstagegetvisible
#else
#define petsclogstagegetvisible_ ppetsclogstagegetvisible_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagegetvisible_ PETSCLOGSTAGEGETVISIBLE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagegetvisible_ petsclogstagegetvisible
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagegetid_ PPETSCLOGSTAGEGETID
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagegetid_ ppetsclogstagegetid
#else
#define petsclogstagegetid_ ppetsclogstagegetid_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogstagegetid_ PETSCLOGSTAGEGETID
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogstagegetid_ petsclogstagegetid
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventactivate_ PPETSCLOGEVENTACTIVATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventactivate_ ppetsclogeventactivate
#else
#define petsclogeventactivate_ ppetsclogeventactivate_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventactivate_ PETSCLOGEVENTACTIVATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventactivate_ petsclogeventactivate
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventdeactivate_ PPETSCLOGEVENTDEACTIVATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventdeactivate_ ppetsclogeventdeactivate
#else
#define petsclogeventdeactivate_ ppetsclogeventdeactivate_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventdeactivate_ PETSCLOGEVENTDEACTIVATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventdeactivate_ petsclogeventdeactivate
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventsetactiveall_ PPETSCLOGEVENTSETACTIVEALL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventsetactiveall_ ppetsclogeventsetactiveall
#else
#define petsclogeventsetactiveall_ ppetsclogeventsetactiveall_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventsetactiveall_ PETSCLOGEVENTSETACTIVEALL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventsetactiveall_ petsclogeventsetactiveall
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventactivateclass_ PPETSCLOGEVENTACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventactivateclass_ ppetsclogeventactivateclass
#else
#define petsclogeventactivateclass_ ppetsclogeventactivateclass_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventactivateclass_ PETSCLOGEVENTACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventactivateclass_ petsclogeventactivateclass
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventdeactivateclass_ PPETSCLOGEVENTDEACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventdeactivateclass_ ppetsclogeventdeactivateclass
#else
#define petsclogeventdeactivateclass_ ppetsclogeventdeactivateclass_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petsclogeventdeactivateclass_ PETSCLOGEVENTDEACTIVATECLASS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petsclogeventdeactivateclass_ petsclogeventdeactivateclass
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscgettime_ PPETSCGETTIME
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscgettime_ ppetscgettime
#else
#define petscgettime_ ppetscgettime_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscgettime_ PETSCGETTIME
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscgettime_ petscgettime
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscloggetstagelog_ PPETSCLOGGETSTAGELOG
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscloggetstagelog_ ppetscloggetstagelog
#else
#define petscloggetstagelog_ ppetscloggetstagelog_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscloggetstagelog_ PETSCLOGGETSTAGELOG
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscloggetstagelog_ petscloggetstagelog
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petsclogtracebegin_(FILE *file, int *ierr ){
*ierr = PetscLogTraceBegin(
	(FILE* )PetscToPointer( (file) ));
}
void PETSC_STDCALL  petsclogactions_(PetscTruth *flag, int *ierr ){
*ierr = PetscLogActions(*flag);
}
void PETSC_STDCALL  petsclogobjects_(PetscTruth *flag, int *ierr ){
*ierr = PetscLogObjects(*flag);
}
void PETSC_STDCALL  petsclogstagesetactive_(int *stage,PetscTruth *isActive, int *ierr ){
*ierr = PetscLogStageSetActive(*stage,*isActive);
}
void PETSC_STDCALL  petsclogstagegetactive_(int *stage,PetscTruth *isActive, int *ierr ){
*ierr = PetscLogStageGetActive(*stage,isActive);
}
void PETSC_STDCALL  petsclogstagesetvisible_(int *stage,PetscTruth *isVisible, int *ierr ){
*ierr = PetscLogStageSetVisible(*stage,*isVisible);
}
void PETSC_STDCALL  petsclogstagegetvisible_(int *stage,PetscTruth *isVisible, int *ierr ){
*ierr = PetscLogStageGetVisible(*stage,isVisible);
}
void PETSC_STDCALL  petsclogstagegetid_( char name[],int *stage, int *ierr ){
*ierr = PetscLogStageGetId(name,stage);
}
void PETSC_STDCALL  petsclogeventactivate_(PetscEvent *event, int *ierr ){
*ierr = PetscLogEventActivate(*event);
}
void PETSC_STDCALL  petsclogeventdeactivate_(PetscEvent *event, int *ierr ){
*ierr = PetscLogEventDeactivate(*event);
}
void PETSC_STDCALL  petsclogeventsetactiveall_(PetscEvent *event,PetscTruth *isActive, int *ierr ){
*ierr = PetscLogEventSetActiveAll(*event,*isActive);
}
void PETSC_STDCALL  petsclogeventactivateclass_(PetscCookie *cookie, int *ierr ){
*ierr = PetscLogEventActivateClass(*cookie);
}
void PETSC_STDCALL  petsclogeventdeactivateclass_(PetscCookie *cookie, int *ierr ){
*ierr = PetscLogEventDeactivateClass(*cookie);
}
void PETSC_STDCALL  petscgettime_(PetscLogDouble *t, int *ierr ){
*ierr = PetscGetTime(t);
}
void PETSC_STDCALL  petscloggetstagelog_(StageLog *stageLog, int *ierr ){
*ierr = PetscLogGetStageLog(stageLog);
}
#if defined(__cplusplus)
}
#endif
