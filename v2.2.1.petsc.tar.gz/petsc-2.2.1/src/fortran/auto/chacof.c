/* chaco.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacosetglobal_ PMATPARTITIONINGCHACOSETGLOBAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacosetglobal_ pmatpartitioningchacosetglobal
#else
#define matpartitioningchacosetglobal_ pmatpartitioningchacosetglobal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacosetglobal_ MATPARTITIONINGCHACOSETGLOBAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacosetglobal_ matpartitioningchacosetglobal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacosetlocal_ PMATPARTITIONINGCHACOSETLOCAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacosetlocal_ pmatpartitioningchacosetlocal
#else
#define matpartitioningchacosetlocal_ pmatpartitioningchacosetlocal_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacosetlocal_ MATPARTITIONINGCHACOSETLOCAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacosetlocal_ matpartitioningchacosetlocal
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacosetcoarselevel_ PMATPARTITIONINGCHACOSETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacosetcoarselevel_ pmatpartitioningchacosetcoarselevel
#else
#define matpartitioningchacosetcoarselevel_ pmatpartitioningchacosetcoarselevel_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacosetcoarselevel_ MATPARTITIONINGCHACOSETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacosetcoarselevel_ matpartitioningchacosetcoarselevel
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacoseteigensolver_ PMATPARTITIONINGCHACOSETEIGENSOLVER
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacoseteigensolver_ pmatpartitioningchacoseteigensolver
#else
#define matpartitioningchacoseteigensolver_ pmatpartitioningchacoseteigensolver_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacoseteigensolver_ MATPARTITIONINGCHACOSETEIGENSOLVER
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacoseteigensolver_ matpartitioningchacoseteigensolver
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacoseteigentol_ PMATPARTITIONINGCHACOSETEIGENTOL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacoseteigentol_ pmatpartitioningchacoseteigentol
#else
#define matpartitioningchacoseteigentol_ pmatpartitioningchacoseteigentol_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacoseteigentol_ MATPARTITIONINGCHACOSETEIGENTOL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacoseteigentol_ matpartitioningchacoseteigentol
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacoseteigennumber_ PMATPARTITIONINGCHACOSETEIGENNUMBER
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacoseteigennumber_ pmatpartitioningchacoseteigennumber
#else
#define matpartitioningchacoseteigennumber_ pmatpartitioningchacoseteigennumber_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningchacoseteigennumber_ MATPARTITIONINGCHACOSETEIGENNUMBER
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningchacoseteigennumber_ matpartitioningchacoseteigennumber
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  matpartitioningchacosetglobal_(MatPartitioning *part,MPChacoGlobalType *method, int *ierr ){
*ierr = MatPartitioningChacoSetGlobal(*part,*method);
}
void PETSC_STDCALL  matpartitioningchacosetlocal_(MatPartitioning *part,MPChacoLocalType *method, int *ierr ){
*ierr = MatPartitioningChacoSetLocal(*part,*method);
}
void PETSC_STDCALL  matpartitioningchacosetcoarselevel_(MatPartitioning *part,PetscReal *level, int *ierr ){
*ierr = MatPartitioningChacoSetCoarseLevel(*part,*level);
}
void PETSC_STDCALL  matpartitioningchacoseteigensolver_(MatPartitioning *part,
    MPChacoEigenType *method, int *ierr ){
*ierr = MatPartitioningChacoSetEigenSolver(*part,*method);
}
void PETSC_STDCALL  matpartitioningchacoseteigentol_(MatPartitioning *part,PetscReal *tol, int *ierr ){
*ierr = MatPartitioningChacoSetEigenTol(*part,*tol);
}
void PETSC_STDCALL  matpartitioningchacoseteigennumber_(MatPartitioning *part,int *num, int *ierr ){
*ierr = MatPartitioningChacoSetEigenNumber(*part,*num);
}
#if defined(__cplusplus)
}
#endif
