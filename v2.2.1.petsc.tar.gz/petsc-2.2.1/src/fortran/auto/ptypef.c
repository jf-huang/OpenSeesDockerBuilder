/* ptype.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petsc.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdatatypetompidatatype_ PPETSCDATATYPETOMPIDATATYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdatatypetompidatatype_ ppetscdatatypetompidatatype
#else
#define petscdatatypetompidatatype_ ppetscdatatypetompidatatype_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdatatypetompidatatype_ PETSCDATATYPETOMPIDATATYPE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdatatypetompidatatype_ petscdatatypetompidatatype
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdatatypegetsize_ PPETSCDATATYPEGETSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdatatypegetsize_ ppetscdatatypegetsize
#else
#define petscdatatypegetsize_ ppetscdatatypegetsize_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define petscdatatypegetsize_ PETSCDATATYPEGETSIZE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define petscdatatypegetsize_ petscdatatypegetsize
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  petscdatatypetompidatatype_(PetscDataType *ptype,MPI_Datatype* mtype, int *ierr ){
*ierr = PetscDataTypeToMPIDataType(*ptype,mtype);
}
void PETSC_STDCALL  petscdatatypegetsize_(PetscDataType *ptype,PetscInt *size, int *ierr ){
*ierr = PetscDataTypeGetSize(*ptype,size);
}
#if defined(__cplusplus)
}
#endif
