/* baij.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matseqbaijsetcolumnindices_ PMATSEQBAIJSETCOLUMNINDICES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matseqbaijsetcolumnindices_ pmatseqbaijsetcolumnindices
#else
#define matseqbaijsetcolumnindices_ pmatseqbaijsetcolumnindices_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matseqbaijsetcolumnindices_ MATSEQBAIJSETCOLUMNINDICES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matseqbaijsetcolumnindices_ matseqbaijsetcolumnindices
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  matseqbaijsetcolumnindices_(Mat mat,PetscInt *indices, int *ierr ){
*ierr = MatSeqBAIJSetColumnIndices(
	(Mat)PetscToPointer( (mat) ),indices);
}
#if defined(__cplusplus)
}
#endif
