/* jostle.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscmat.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningjostlesetcoarselevel_ PMATPARTITIONINGJOSTLESETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningjostlesetcoarselevel_ pmatpartitioningjostlesetcoarselevel
#else
#define matpartitioningjostlesetcoarselevel_ pmatpartitioningjostlesetcoarselevel_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningjostlesetcoarselevel_ MATPARTITIONINGJOSTLESETCOARSELEVEL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningjostlesetcoarselevel_ matpartitioningjostlesetcoarselevel
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningjostlesetcoarsesequential_ PMATPARTITIONINGJOSTLESETCOARSESEQUENTIAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningjostlesetcoarsesequential_ pmatpartitioningjostlesetcoarsesequential
#else
#define matpartitioningjostlesetcoarsesequential_ pmatpartitioningjostlesetcoarsesequential_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define matpartitioningjostlesetcoarsesequential_ MATPARTITIONINGJOSTLESETCOARSESEQUENTIAL
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define matpartitioningjostlesetcoarsesequential_ matpartitioningjostlesetcoarsesequential
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  matpartitioningjostlesetcoarselevel_(MatPartitioning *part,PetscReal *level, int *ierr ){
*ierr = MatPartitioningJostleSetCoarseLevel(*part,*level);
}
void PETSC_STDCALL  matpartitioningjostlesetcoarsesequential_(MatPartitioning *part, int *ierr ){
*ierr = MatPartitioningJostleSetCoarseSequential(*part);
}
#if defined(__cplusplus)
}
#endif
