/* itcreate.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscksp.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define kspsetoperators_ PKSPSETOPERATORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define kspsetoperators_ pkspsetoperators
#else
#define kspsetoperators_ pkspsetoperators_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define kspsetoperators_ KSPSETOPERATORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define kspsetoperators_ kspsetoperators
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define kspgetoperators_ PKSPGETOPERATORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define kspgetoperators_ pkspgetoperators
#else
#define kspgetoperators_ pkspgetoperators_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define kspgetoperators_ KSPGETOPERATORS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define kspgetoperators_ kspgetoperators
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define kspsetfromoptions_ PKSPSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define kspsetfromoptions_ pkspsetfromoptions
#else
#define kspsetfromoptions_ pkspsetfromoptions_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define kspsetfromoptions_ KSPSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define kspsetfromoptions_ kspsetfromoptions
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  kspsetoperators_(KSP ksp,Mat Amat,Mat Pmat,MatStructure *flag, int *ierr ){
*ierr = KSPSetOperators(
	(KSP)PetscToPointer( (ksp) ),
	(Mat)PetscToPointer( (Amat) ),
	(Mat)PetscToPointer( (Pmat) ),*flag);
}
void PETSC_STDCALL  kspgetoperators_(KSP ksp,Mat *Amat,Mat *Pmat,MatStructure *flag, int *ierr ){
*ierr = KSPGetOperators(
	(KSP)PetscToPointer( (ksp) ),Amat,Pmat,
	(MatStructure* )PetscToPointer( (flag) ));
}
void PETSC_STDCALL  kspsetfromoptions_(KSP ksp, int *ierr ){
*ierr = KSPSetFromOptions(
	(KSP)PetscToPointer( (ksp) ));
}
#if defined(__cplusplus)
}
#endif
