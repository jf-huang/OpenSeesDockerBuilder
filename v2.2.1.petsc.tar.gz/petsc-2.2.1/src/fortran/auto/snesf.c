/* snes.c */
/* Fortran interface file */

/*
* This file was generated automatically by bfort from the C source
* file.  
 */

#ifdef PETSC_USE_POINTER_CONVERSION
#if defined(__cplusplus)
extern "C" { 
#endif 
extern void *PetscToPointer(void*);
extern int PetscFromPointer(void *);
extern void PetscRmPointer(void*);
#if defined(__cplusplus)
} 
#endif 

#else

#define PetscToPointer(a) (*(long *)(a))
#define PetscFromPointer(a) (long)(a)
#define PetscRmPointer(a)
#endif

#include "petscfix.h"
#include "petscsnes.h"
#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetfromoptions_ PSNESSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetfromoptions_ psnessetfromoptions
#else
#define snessetfromoptions_ psnessetfromoptions_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetfromoptions_ SNESSETFROMOPTIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetfromoptions_ snessetfromoptions
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetapplicationcontext_ PSNESSETAPPLICATIONCONTEXT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetapplicationcontext_ psnessetapplicationcontext
#else
#define snessetapplicationcontext_ psnessetapplicationcontext_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetapplicationcontext_ SNESSETAPPLICATIONCONTEXT
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetapplicationcontext_ snessetapplicationcontext
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetiterationnumber_ PSNESGETITERATIONNUMBER
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetiterationnumber_ psnesgetiterationnumber
#else
#define snesgetiterationnumber_ psnesgetiterationnumber_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetiterationnumber_ SNESGETITERATIONNUMBER
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetiterationnumber_ snesgetiterationnumber
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetfunctionnorm_ PSNESGETFUNCTIONNORM
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetfunctionnorm_ psnesgetfunctionnorm
#else
#define snesgetfunctionnorm_ psnesgetfunctionnorm_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetfunctionnorm_ SNESGETFUNCTIONNORM
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetfunctionnorm_ snesgetfunctionnorm
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetnumberunsuccessfulsteps_ PSNESGETNUMBERUNSUCCESSFULSTEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetnumberunsuccessfulsteps_ psnesgetnumberunsuccessfulsteps
#else
#define snesgetnumberunsuccessfulsteps_ psnesgetnumberunsuccessfulsteps_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetnumberunsuccessfulsteps_ SNESGETNUMBERUNSUCCESSFULSTEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetnumberunsuccessfulsteps_ snesgetnumberunsuccessfulsteps
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetmaximumunsuccessfulsteps_ PSNESSETMAXIMUMUNSUCCESSFULSTEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetmaximumunsuccessfulsteps_ psnessetmaximumunsuccessfulsteps
#else
#define snessetmaximumunsuccessfulsteps_ psnessetmaximumunsuccessfulsteps_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetmaximumunsuccessfulsteps_ SNESSETMAXIMUMUNSUCCESSFULSTEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetmaximumunsuccessfulsteps_ snessetmaximumunsuccessfulsteps
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetmaximumunsuccessfulsteps_ PSNESGETMAXIMUMUNSUCCESSFULSTEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetmaximumunsuccessfulsteps_ psnesgetmaximumunsuccessfulsteps
#else
#define snesgetmaximumunsuccessfulsteps_ psnesgetmaximumunsuccessfulsteps_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetmaximumunsuccessfulsteps_ SNESGETMAXIMUMUNSUCCESSFULSTEPS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetmaximumunsuccessfulsteps_ snesgetmaximumunsuccessfulsteps
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetnumberlineariterations_ PSNESGETNUMBERLINEARITERATIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetnumberlineariterations_ psnesgetnumberlineariterations
#else
#define snesgetnumberlineariterations_ psnesgetnumberlineariterations_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgetnumberlineariterations_ SNESGETNUMBERLINEARITERATIONS
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgetnumberlineariterations_ snesgetnumberlineariterations
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snescomputefunction_ PSNESCOMPUTEFUNCTION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snescomputefunction_ psnescomputefunction
#else
#define snescomputefunction_ psnescomputefunction_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snescomputefunction_ SNESCOMPUTEFUNCTION
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snescomputefunction_ snescomputefunction
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snescomputejacobian_ PSNESCOMPUTEJACOBIAN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snescomputejacobian_ psnescomputejacobian
#else
#define snescomputejacobian_ psnescomputejacobian_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snescomputejacobian_ SNESCOMPUTEJACOBIAN
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snescomputejacobian_ snescomputejacobian
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetup_ PSNESSETUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetup_ psnessetup
#else
#define snessetup_ psnessetup_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetup_ SNESSETUP
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetup_ snessetup
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessettolerances_ PSNESSETTOLERANCES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessettolerances_ psnessettolerances
#else
#define snessettolerances_ psnessettolerances_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessettolerances_ SNESSETTOLERANCES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessettolerances_ snessettolerances
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgettolerances_ PSNESGETTOLERANCES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgettolerances_ psnesgettolerances
#else
#define snesgettolerances_ psnesgettolerances_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesgettolerances_ SNESGETTOLERANCES
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesgettolerances_ snesgettolerances
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessettrustregiontolerance_ PSNESSETTRUSTREGIONTOLERANCE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessettrustregiontolerance_ psnessettrustregiontolerance
#else
#define snessettrustregiontolerance_ psnessettrustregiontolerance_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessettrustregiontolerance_ SNESSETTRUSTREGIONTOLERANCE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessettrustregiontolerance_ snessettrustregiontolerance
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetconvergencehistory_ PSNESSETCONVERGENCEHISTORY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetconvergencehistory_ psnessetconvergencehistory
#else
#define snessetconvergencehistory_ psnessetconvergencehistory_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessetconvergencehistory_ SNESSETCONVERGENCEHISTORY
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessetconvergencehistory_ snessetconvergencehistory
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesdefaultrhsbc_ PSNESDEFAULTRHSBC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesdefaultrhsbc_ psnesdefaultrhsbc
#else
#define snesdefaultrhsbc_ psnesdefaultrhsbc_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesdefaultrhsbc_ SNESDEFAULTRHSBC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesdefaultrhsbc_ snesdefaultrhsbc
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesdefaultsolutionbc_ PSNESDEFAULTSOLUTIONBC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesdefaultsolutionbc_ psnesdefaultsolutionbc
#else
#define snesdefaultsolutionbc_ psnesdefaultsolutionbc_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesdefaultsolutionbc_ SNESDEFAULTSOLUTIONBC
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesdefaultsolutionbc_ snesdefaultsolutionbc
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesdefaultupdate_ PSNESDEFAULTUPDATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesdefaultupdate_ psnesdefaultupdate
#else
#define snesdefaultupdate_ psnesdefaultupdate_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snesdefaultupdate_ SNESDEFAULTUPDATE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snesdefaultupdate_ snesdefaultupdate
#endif
#endif

#ifdef MPI_BUILD_PROFILING
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessolve_ PSNESSOLVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessolve_ psnessolve
#else
#define snessolve_ psnessolve_
#endif
#else
#ifdef PETSC_HAVE_FORTRAN_CAPS
#define snessolve_ SNESSOLVE
#elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE) && !defined(FORTRANDOUBLEUNDERSCORE)
#define snessolve_ snessolve
#endif
#endif



/* Definitions of Fortran Wrapper routines */
#if defined(__cplusplus)
extern "C" {
#endif
void PETSC_STDCALL  snessetfromoptions_(SNES snes, int *ierr ){
*ierr = SNESSetFromOptions(
	(SNES)PetscToPointer( (snes) ));
}
void PETSC_STDCALL  snessetapplicationcontext_(SNES snes,void*usrP, int *ierr ){
*ierr = SNESSetApplicationContext(
	(SNES)PetscToPointer( (snes) ),usrP);
}
void PETSC_STDCALL  snesgetiterationnumber_(SNES snes,PetscInt* iter, int *ierr ){
*ierr = SNESGetIterationNumber(
	(SNES)PetscToPointer( (snes) ),iter);
}
void PETSC_STDCALL  snesgetfunctionnorm_(SNES snes,PetscScalar *fnorm, int *ierr ){
*ierr = SNESGetFunctionNorm(
	(SNES)PetscToPointer( (snes) ),fnorm);
}
void PETSC_STDCALL  snesgetnumberunsuccessfulsteps_(SNES snes,PetscInt* nfails, int *ierr ){
*ierr = SNESGetNumberUnsuccessfulSteps(
	(SNES)PetscToPointer( (snes) ),nfails);
}
void PETSC_STDCALL  snessetmaximumunsuccessfulsteps_(SNES snes,PetscInt *maxFails, int *ierr ){
*ierr = SNESSetMaximumUnsuccessfulSteps(
	(SNES)PetscToPointer( (snes) ),*maxFails);
}
void PETSC_STDCALL  snesgetmaximumunsuccessfulsteps_(SNES snes,PetscInt *maxFails, int *ierr ){
*ierr = SNESGetMaximumUnsuccessfulSteps(
	(SNES)PetscToPointer( (snes) ),maxFails);
}
void PETSC_STDCALL  snesgetnumberlineariterations_(SNES snes,PetscInt* lits, int *ierr ){
*ierr = SNESGetNumberLinearIterations(
	(SNES)PetscToPointer( (snes) ),lits);
}
void PETSC_STDCALL  snescomputefunction_(SNES snes,Vec x,Vec y, int *ierr ){
*ierr = SNESComputeFunction(
	(SNES)PetscToPointer( (snes) ),
	(Vec)PetscToPointer( (x) ),
	(Vec)PetscToPointer( (y) ));
}
void PETSC_STDCALL  snescomputejacobian_(SNES snes,Vec X,Mat *A,Mat *B,MatStructure *flg, int *ierr ){
*ierr = SNESComputeJacobian(
	(SNES)PetscToPointer( (snes) ),
	(Vec)PetscToPointer( (X) ),A,B,
	(MatStructure* )PetscToPointer( (flg) ));
}
void PETSC_STDCALL  snessetup_(SNES snes,Vec x, int *ierr ){
*ierr = SNESSetUp(
	(SNES)PetscToPointer( (snes) ),
	(Vec)PetscToPointer( (x) ));
}
void PETSC_STDCALL  snessettolerances_(SNES snes,PetscReal *abstol,PetscReal *rtol,PetscReal *stol,PetscInt *maxit,PetscInt *maxf, int *ierr ){
*ierr = SNESSetTolerances(
	(SNES)PetscToPointer( (snes) ),*abstol,*rtol,*stol,*maxit,*maxf);
}
void PETSC_STDCALL  snesgettolerances_(SNES snes,PetscReal *abstol,PetscReal *rtol,PetscReal *stol,PetscInt *maxit,PetscInt *maxf, int *ierr ){
*ierr = SNESGetTolerances(
	(SNES)PetscToPointer( (snes) ),abstol,rtol,stol,maxit,maxf);
}
void PETSC_STDCALL  snessettrustregiontolerance_(SNES snes,PetscReal *tol, int *ierr ){
*ierr = SNESSetTrustRegionTolerance(
	(SNES)PetscToPointer( (snes) ),*tol);
}
void PETSC_STDCALL  snessetconvergencehistory_(SNES snes,PetscReal a[],PetscInt *its,PetscInt *na,PetscTruth *reset, int *ierr ){
*ierr = SNESSetConvergenceHistory(
	(SNES)PetscToPointer( (snes) ),a,its,*na,*reset);
}
void PETSC_STDCALL  snesdefaultrhsbc_(SNES snes,Vec rhs,void*ctx, int *ierr ){
*ierr = SNESDefaultRhsBC(
	(SNES)PetscToPointer( (snes) ),
	(Vec)PetscToPointer( (rhs) ),ctx);
}
void PETSC_STDCALL  snesdefaultsolutionbc_(SNES snes,Vec sol,void*ctx, int *ierr ){
*ierr = SNESDefaultSolutionBC(
	(SNES)PetscToPointer( (snes) ),
	(Vec)PetscToPointer( (sol) ),ctx);
}
void PETSC_STDCALL  snesdefaultupdate_(SNES snes,PetscInt *step, int *ierr ){
*ierr = SNESDefaultUpdate(
	(SNES)PetscToPointer( (snes) ),*step);
}
void PETSC_STDCALL  snessolve_(SNES snes,Vec x, int *ierr ){
*ierr = SNESSolve(
	(SNES)PetscToPointer( (snes) ),
	(Vec)PetscToPointer( (x) ));
}
#if defined(__cplusplus)
}
#endif
