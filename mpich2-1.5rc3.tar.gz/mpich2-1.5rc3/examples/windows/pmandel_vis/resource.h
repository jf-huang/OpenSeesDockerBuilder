/* -*- Mode: C; c-basic-offset:4 ; -*- */
/*
 *
 *  (C) 2001 by Argonne National Laboratory.
 *      See COPYRIGHT in top-level directory.
 */
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by pman_vis.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_pman_visTYPE                129
#define IDD_DIALOG1                     130
#define IDD_CONNECT_DIALOG              130
#define IDD_BOUNDS_DLG                  131
#define IDD_DEMO_POINTS_DLG             132
#define IDD_ABOUND_DLG                  133
#define IDC_HOSTNAME                    1000
#define IDC_PORT                        1001
#define IDC_MPI_RADIO                   1002
#define IDC_TCP_RADIO                   1003
#define IDC_MPIPORT                     1004
#define IDC_CONNECT_GROUP               1005
#define IDC_XMIN_EDIT                   1006
#define IDC_YMIN_EDIT                   1007
#define IDC_XMAX_EDIT                   1008
#define IDC_YMAX_EDIT                   1010
#define IDC_MAX_ITER_EDIT               1011
#define IDC_POINTS_LIST                 1012
#define IDC_ADD_BTN                     1013
#define IDC_LOAD_BTN                    1014
#define ID_FILE_CONNECT                 32771
#define ID_FILE_ENTERPOINT              32772
#define ID_FILE_ENTERDEMOPOINTS         32773
#define ID_FILE_STOPDEMO                32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
